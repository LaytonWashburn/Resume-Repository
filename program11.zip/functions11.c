#include"header11.h"

int contents[STACK_SIZE]; //Declare array
int top = 0;				//Declare and initialize variable

/*******************************************************************************
*Funtion Title: make_empty
*
*Summary: Makes the top of the stack equal to zero
*
*Inputs:None
*Outputs:None
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Begin
*		Makes the top of the stack equal to zero
*	End
*******************************************************************************/
void make_empty(void)
{						//Begin
	top = 0;			//Makes the top of the stack equal to zero
}						//End
/*******************************************************************************
*Funtion Title:is_empty
*
*Summary:Returns top is equal to 0
*
*Inputs:None
*Outputs:Boolean value
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Begin
*		Returns top is equal to zero
*	End
*******************************************************************************/

bool is_empty(void)
{						//Begin
	return top == 0;	//Returns top is equal to zero
}						//End
/*******************************************************************************
*Funtion Title:is_full
*
*Summary: Returns top is equal to the stack size 
*
*Inputs:None
*Outputs:Boolean value
*
*Compile Instructions:
********************************************************************************
*Pseudocode
*	Begin
*		Returns top is equal to the stack size
*	End
*******************************************************************************/

bool is_full(void)
{								//Begin
	return top == STACK_SIZE; //Returns top is equal to the stack size
}								//End
/*******************************************************************************
*Funtion Title:push
*
*Summary: Pushes a number onto the stack
*
*Inputs: int i
*Outputs: None
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Begin
*		If top is equal to stack size
*			Perform stack_overflow function
*		else
*			Push number onto stack
*	End
*******************************************************************************/

void push(int i)
{					//Begin
	if(is_full())	//If top is equal to stack size
		stack_overflow();//Perform stack_overflow function
	else			//else
		contents[top++] = i; //Push number onto stack
}					//End
/*******************************************************************************
*Funtion Title:pop
*
*Summary:Takes a number off of the stack
*
*Inputs:None
*Outputs:Integer
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Begin
*		If not enough operands
*			Print Not enough operands to screen
*		else
*			return the top stack value
*	End
*******************************************************************************/

int pop(void)
{				//Begin
	if(is_empty()) //If not enough operands
		stack_underflow();//Print Not enough operands to screen
	else 			//else
		return contents[--top];//return the top stack value
}				//End
/*******************************************************************************
*Funtion Title:stack_overflow
*
*Summary:If expression does not have enough operators,it returns string
*
*Inputs:None
*Outputs:None
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Begin
*		Prints Expression is too complex to screen
*		exit
*	End
*******************************************************************************/

void stack_overflow(void)
{							//Begin
	//Prints Expression is too complex to screen
	printf("Expression is too complex\n");
	exit(1);  //exit
}							//End
/*******************************************************************************
*Funtion Title:stack_underflow
*
*Summary:Reutrns string if there are not enough operands
*
*Inputs:None 
*Outputs:None 
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Begin
*		Prints Not enough Operands to screen
*		exit
*	End
*******************************************************************************/

void stack_underflow(void)
{							//Begin
	printf("Not enough Operands\n"); //Prints Not enough Operands to screen
	exit(1);					//exit
}							//End