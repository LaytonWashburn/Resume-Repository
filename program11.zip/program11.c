#include "header11.h"
/*******************************************************************************
*Function Title: Main
*
*Summary: Computes RPN value
*
*Input: None
*Output: None
*
*Compile Instructions: gcc compiler
********************************************************************************
*Pseudocode
*	Begin
*		Declare variables 
*		Print Enter an RPN Expression to screen
*		Begin For loop
*			get input from keyboard
*			if ch is equal to = break from for loop
*			if ch is between 0 or 9
*				push ch onto stack
*			else 
*				pop top of stack
*				pop top of stack
*			switch on ch
*				if operand is addition
*					Add the top and one below top of stack
*					push answer onto stack
*					break
*				if operand is substraction
*					Subtract top and one below top of stack
*					push answer onto stack
*					break
*				if operand is multiplication
*					Multiply top and one below top of stack
*					Push answer onto stack
*					break
*				if operand is division
*					Divid top and one below top of stack
*					Push answer onto stack
*					break
*				Prints value of RPN expression to screen				
*	End
*******************************************************************************/
int main(void)
{
	
	int num1, num2, answ;	//Declare variables
	char ch;
	
	//Print Enter an RPN Expression to screen
	printf("Enter an RPN Expression: "); 
	for(; ;)
	{
		scanf("%c", &ch);  //get input from keyboard
		
		if(ch == '=')//if ch is equal to = break from for loop
		{
			printf("Value of Expression: %d", pop());
			return 0;
		}
		
		if (ch >= 48 && ch <= 57)//if ch is between 0 or 9
		{
			push(((int)ch - 48 )); // push ch onto stack
		}
		
		else
		{
			num1 = pop();	//pop top of stack
			num2 = pop();	//pop top of stack
			
			switch(ch)	//switch on ch
			{
				case '+': //if operand is addition
					answ = num2 + num1;// Add the top and one below top of stack
					//printf(" + pushing %d onto stack\n", answ);
					push(answ);//push answer onto stack
					break;//break
				
				case '-'://if operand is subtraction
					answ = num2 - num1;//Subtract top and one below top of stack
					//printf(" - pushing %d onto stack\n", answ);
					push(answ); //push answer onto stack
					break;//break
				
				case '*': //if operand is multiplication
					answ = num2 * num1;//Multiply top and one below top of stack
					//printf(" * pushing %d onto stack\n", answ);
					push(answ);//Push answer onto stack
					break;//break
				
				case '/': //if operand is division
					answ = num2 / num1; //Divid top and one below top of stack
					//printf(" / pushing %d onto stack\n", answ);
					push(answ); //Push answer onto stack
					break;//break
			}
			//printf("Value of Expression: %d\n", pop());
		}
	}	
	//Prints value of RPN expression to screen
	
	return 0;//end
}