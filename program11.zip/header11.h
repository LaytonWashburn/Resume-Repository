#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#define STACK_SIZE 100
#ifndef HEADER11_H
#define HEADER11_H 
/*******************************************************************************
*Funtion Title:Header
*
*Summary:Lists the libraries and marco definitions
*
*Inputs:None
*Outputs:None
*
*Compile Instructions:None
********************************************************************************
*Pseudocode
*	Declare array
*	Declare and initialize variable
*	make_empty function prototype
*	is_empty function prototype
*	is_full function prototype
*	push function prototype
*	pop function prototype
*	stack_underflow function prototype
*	stack_overflow function prototype
*******************************************************************************/

void make_empty(void);//make_empty function prototype
bool is_empty(void);//is_empty function prototype
bool is_full(void);//is_full function prototype
void push(int i);//push function prototype
int pop(void);//pop function prototype
void stack_underflow(void);//stack_underflow function prototype
void stack_overflow(void);//stack_overflow function prototype
#endif