#include "myLinkedlist.h"
/*******************************************************************************
*Function Title: add_to_list
*
*Summary: Adds inputed number to the value field of the linked list
*
*Input: pointer to struct node and integer
*Output: Pointer to struct node 
*
*Compile Instructions: Not main, compile instructions in main function
********************************************************************************
*Pseudocode
*	Begin
*		Declare pointers to struct node
*		allocated memory for node
*		checks if it allocated space
*			prints error to screen
*			exit function
*		assigns new_node value of a 
*		Moves through the linked list
*		If value already exists
*			Free/delete node
*		Else
*			If prev is equal to NULL
*				If prev is equal to NULL
*			Else
*				points prev's next field to new_node
*		points new_nodes' value to cur	
*		Returns where the list starts
*	End
*******************************************************************************/

struct node * add_to_list(struct node *first, int a)
{												//Begin
	struct node *prev, *cur, *new_node;	//Declare pointers to struct node
	
	new_node = malloc(sizeof(struct node));		//allocated memory for node
	if(new_node == NULL)						//checks if it allocated space
	{	
		printf("ERROR");						//prints error to screen
		exit(1);								//exit function
	}
	
	new_node->value = a; //assigns new_node value of a 
	
	//Moves through the linked list
	for(cur = first, prev = NULL; cur != NULL && new_node->value > cur->value;
		prev = cur, cur = cur->next)	
	{
			
	}
	if(cur != NULL && new_node->value == cur->value)//If value already exists 
	{
		free(new_node);								//Free/delete node
	}
	else											//Else
	{
		if(prev == NULL)							//If prev is equal to NULL
		{
			first = new_node;					//Set first equal to new_node
		}
		else									//Else
		{
			prev->next = new_node;		//points prev's next field to new_node
		}
		
		
		new_node->next = cur;				//points new_nodes' value to cur
	}
	return first; //Returns where the list starts
}//End


/*******************************************************************************
*Function Title: printt_list
*
*Summary: Prints Linked list value field with sine, cosine 
*		  and tangent to output file
*
*Input:Pointer to a struct node, Pointer to a file
*Output:None
*
*Compile Instructions:None, compile intructions in main function
********************************************************************************
*Pseudocode 
*	Begin
*		while p is not NULL
*			Prints to source_out value in node and the sin, cos and tan of value
*			moves to the next node
*	End
*******************************************************************************/

void print_table(struct node *first, FILE *source_out)
{							//Begin
	while (first != NULL)	//while p is not NULL
	{
		//Prints to source_out value in node and the sin, cos and tan of value
		fprintf(source_out, "%2d%15.4f%15.4f%15.4f\n", first->value, 
							sin(first->value), cos(first->value), 
							tan(first->value));
							
		first = first->next; //moves to the next node
	}
}							//End

/*******************************************************************************
*Function Title: clean_list
*
*Summary: Clears the linked list 
*
*Input: Pointer to struct node 
*Output: None 
*
*Compile Instructions: None, compile instructions in main functions
********************************************************************************
*Psuedocode
*	Begin 
*		Declare and Initialize q to NULL
*		While first is not NULL
*			q equals first
*			First equals first next field
*			Frees q allocated space
*	End 
*******************************************************************************/

void clean_list(struct node *first)
{									//Begin
	struct node *q = NULL;			//Declare and Initialize q to NULL
	
	while(first != NULL)		//While first is not NULL
	{
		q = first;				//q equals first
		first = first->next;   //First equals first next field
		free(q);				//Frees q allocated space
	}
}									//End