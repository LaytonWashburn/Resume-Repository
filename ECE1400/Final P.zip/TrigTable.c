#include "myLinkedlist.h"


/*******************************************************************************
*Function Title: Main
*
*Summary: Reads a file and computes a table of sine, cosine and tangent
*
*Input: file
*Output: None
*
*Compile Instructions: gcc compiler, make, ./TrigTable.exe filename
********************************************************************************
*Pseudocode 
*	Begin
*		Declare and initialize struct
*		Declare file pointers
*		Declare variables
*		If the number of command line arguments is not three
*			Print error to screen
*			exit function
*		open the second command line argument
*		If the file does not open
*			Print error to screen
*			Exit function
*		open the third command line argument
*		if the file does not open
*			print error to screen
*			exit function
*		while not the end of the input file
*			read through input file and place numners in num variable
*			adds num to linked list
*		print ordered numbers with sine, cosine and tangent values in column
*		Clears linked list
*		closes input file
*		closes output file
*	End
*******************************************************************************/


int main (int argc, char *argv[])
{									//Begin
	struct node *list = NULL;		//Declare and initialize struct
	FILE *source_in, *source_out;	//Declare file pointers
	
	int num;						//Declare variables
	
	
	
	if (argc != 3)		//If the number of command line arguments is not three
	{
		printf("Error\n");//Print error to screen
		exit(1);		//exit function
	}

	
	source_in = fopen(argv[1], "r"); //open the second command line argument
	if(source_in == NULL)		//If the file does not open
	{
		printf("ERROR\n");		//Print error to screen
		exit(1);				//Exit function
	}

	
	source_out = fopen(argv[2], "w");//open the third command line argument
	if (source_out == NULL)//if the file does not open
	{
		printf("ERROR\n"); //print error to screen
		exit(1);//exit function
	}
	
	
	while (!feof(source_in))//while not the end of the input file
	{
		//read through input file and place numners in num variable
		fscanf(source_in, "%d ", &num);
		list = add_to_list(list, num);//adds num to linked list
	}
	
	
	//print ordered numbers with sine, cosine and tangent values in column
	print_table(list, source_out); 
	
	
	clean_list(list);//Clears linked list
	
	

	fclose(source_in);//closes input file
	fclose(source_out);//closes output file

return 0;
	
}//End