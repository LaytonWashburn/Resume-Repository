#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
/*******************************************************************************
*Function Title: List of prototypes 
*
*Summary: Lets the .c files use these prototypes if they are listed 
*
*Input: None
*Output: None 
*
*Compile Instructions: None, Main function has the compile instructions
********************************************************************************
*Pseudocode
*	Begin header protection
*		Structure Tag
*			value field
*			next field
*		add_to_list function prototype
*		printf_table function prototype  
*		clean_list function prototype
*	End header protection
*******************************************************************************/
#ifndef MYLINKEDLIST_H //Begin header protection
#define MYLINKELIST_H
struct node //Structure Tag
{
	int value; //value field
	struct node *next;//next field
};
//add_to_list function prototype
struct node * add_to_list(struct node *first, int a);
//printf_table function prototype  
void print_table(struct node *first, FILE *source_out);
void clean_list(struct node *first);//clean_list function prototype
#endif //End header protection